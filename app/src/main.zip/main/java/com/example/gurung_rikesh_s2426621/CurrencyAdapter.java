package com.example.gurung_rikesh_s2426621;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.graphics.Color;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CurrencyAdapter extends RecyclerView.Adapter<CurrencyAdapter.CurrencyViewHolder> {

    private ArrayList<CurrencyFx> currencyList;

    public interface OnItemClickListener {
        void onItemClick(CurrencyFx item);
    }

    private OnItemClickListener listener;

    public CurrencyAdapter(ArrayList<CurrencyFx> currencyList, OnItemClickListener listener) {
        this.currencyList = currencyList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CurrencyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_currency, parent, false);
        return new CurrencyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CurrencyViewHolder holder, int position) {
        CurrencyFx item = currencyList.get(position);

        // Title from RSS is like "GBP/EUR"
        holder.txtCurrencyCode.setText(item.title);  // we’ll improve this later
        holder.txtCurrencyTitle.setText(item.description);
        holder.txtCurrencyRate.setText(String.valueOf(item.rateValue));

        // Colour coding based on rateValue
        double rate = item.rateValue;
        if (rate < 1.0) {
            holder.itemView.setBackgroundColor(Color.parseColor("#FFCDD2")); // light red
        } else if (rate < 5.0) {
            holder.itemView.setBackgroundColor(Color.parseColor("#FFF9C4")); // light yellow
        } else if (rate < 10.0) {
            holder.itemView.setBackgroundColor(Color.parseColor("#C8E6C9")); // light green
        } else {
            holder.itemView.setBackgroundColor(Color.parseColor("#BBDEFB")); // light blue
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return currencyList.size();
    }

    public void updateList(ArrayList<CurrencyFx> newList) {
        this.currencyList = newList;
        notifyDataSetChanged();
    }

    static class CurrencyViewHolder extends RecyclerView.ViewHolder {
        TextView txtCurrencyCode, txtCurrencyTitle, txtCurrencyRate;

        public CurrencyViewHolder(@NonNull View itemView) {
            super(itemView);
            txtCurrencyCode = itemView.findViewById(R.id.txtCurrencyCode);
            txtCurrencyTitle = itemView.findViewById(R.id.txtCurrencyTitle);
            txtCurrencyRate = itemView.findViewById(R.id.txtCurrencyRate);
        }
    }
}
