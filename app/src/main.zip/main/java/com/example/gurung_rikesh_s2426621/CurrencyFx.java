package com.example.gurung_rikesh_s2426621;

public class CurrencyFx {
    public String title;        // e.g. GBP/USD
    public String description;  // contains the exchange rate
    public String pubDate;      // optional
    public double rateValue;    // extracted numeric exchange rate
}
