/*  Starter project for Mobile Platform Development - 1st diet 25/26
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 Rikesh Gurung
// Student ID           s2426621
// Programme of Study   Mobile Platform Development
//

// UPDATE THE PACKAGE NAME to include your Student Identifier
package com.example.gurung_rikesh_s2426621;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View.OnClickListener;
import androidx.appcompat.app.AppCompatActivity;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    private TextView rawDataDisplay;
    private RecyclerView recyclerViewCurrencies;
    private CurrencyAdapter adapter;
    private ArrayList<CurrencyFx> currencyList = new ArrayList<>();

    private TextView txtLastUpdated;
    private Button startButton;
    private String result = "";
    private String url1="";
    private String urlSource="https://www.fx-exchange.com/gbp/rss.xml";
    ImageView imgFromFlag, imgToFlag;
    TextView txtFromCode, txtToCode, txtFromValue, txtToValue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Set up the raw links to the graphical components
        //rawDataDisplay = (TextView)findViewById(R.id    .rawDataDisplay);
        //startButton = (Button)findViewById(R.id.startButton);
        //startButton.setOnClickListener(this);

        // More Code goes here
        rawDataDisplay = null; // we don't use it anymore, you can delete the field

        txtLastUpdated = findViewById(R.id.txtLastUpdated);

        recyclerViewCurrencies = findViewById(R.id.recyclerViewCurrencies);
        recyclerViewCurrencies.setLayoutManager(new LinearLayoutManager(this));

        adapter = new CurrencyAdapter(currencyList, item -> {
            // TODO: open conversion screen here later
        });
        recyclerViewCurrencies.setAdapter(adapter);

        startButton = findViewById(R.id.startButton);
        startButton.setOnClickListener(this);


    }

    public void onClick(View aview)
    {
        startProgress();
    }

    public void startProgress()
    {
        // Run network access on a separate thread;
        new Thread(new Task(urlSource)).start();
    } //

    // Need separate thread to access the internet resource over network
    // Other neater solutions should be adopted in later iterations.
    private class Task implements Runnable {
        private String url;

        public Task(String aurl) {
            url = aurl;
        }

        @Override
        public void run() {
            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.d("MyTask", "in run");

            try {
                Log.d("MyTask", "in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                while ((inputLine = in.readLine()) != null) {
                    result = result + inputLine;
                }
                in.close();
                Log.e("DEBUG", "Downloaded XML size = " + result.length());
            } catch (IOException ae) {
                Log.e("MyTask", "ioexception");
            }

            //Clean up any leading garbage characters
            int i = result.indexOf("<?"); //initial tag
            result = result.substring(i);

            //Clean up any trailing garbage at the end of the file
            i = result.indexOf("</rss>"); //final tag
            result = result.substring(0, i + 6);

            // Now that you have the xml data into result, you can parse it
            try {
                XmlPullParserFactory factory =
                        XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput(new StringReader(result));

                //Parsing Currency
                Log.e("TEST", "PARSING BLOCK REACHED!");
                CurrencyPullParser parser = new CurrencyPullParser();
                ArrayList<CurrencyFx> items = parser.parse(result);

                currencyList = items;
                /* StringBuilder sb = new StringBuilder();
                for (CurrencyFx fx : items) {
                    sb.append(fx.title)
                            .append(" -> ")
                            .append(fx.rateValue)
                            .append("\n");
                }

                result = sb.toString();*/


            } catch (XmlPullParserException e) {
                Log.e("Parsing", "EXCEPTION" + e);
                //throw new RuntimeException(e);
            }

                // Now update the TextView to display raw XML data
                // Probably not the best way to update TextView
                // but we are just getting started !

                MainActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        Log.d("UI thread", "I am the UI thread");
                        //rawDataDisplay.setText(result);
                        // update adapter with new data
                        adapter.updateList(currencyList);

                        // update last updated text (simple version)
                        txtLastUpdated.setText("Last updated: just now");

                    }
                });


        }
    }
}